const authJwt = require("./authJwt");
const { Avatar, Cover } = require("./uploadImage");
module.exports = {
  authJwt,
  Avatar,
  Cover,
};
