module.exports = {
  secret: "gfg_jwt_secret_key",
};
